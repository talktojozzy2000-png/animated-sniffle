document.addEventListener('DOMContentLoaded', () => {
  const kycForm = document.getElementById('kycForm');
  if (kycForm) {
    kycForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = document.getElementById('kycStatus');
      status.innerHTML = "Encrypting files and submitting... (demo)";
      const idFile = document.getElementById('idUpload').files[0];
      if (!idFile) { status.innerText = "Please upload an ID."; return; }
      const toBase64 = (file) => new Promise((res, rej) => {
        const reader = new FileReader();
        reader.onload = () => res(reader.result);
        reader.onerror = () => rej('file read error');
        reader.readAsDataURL(file);
      });
      try {
        await toBase64(idFile);
        localStorage.setItem('pn_kyc_status', 'pending');
        status.innerHTML = "KYC submitted. Status: <strong>Pending</strong>. (This is a demo.)";
      } catch (err) {
        status.innerText = 'Error reading file.';
      }
    });
  }

  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const dashboard = document.getElementById('dashboard');
      dashboard.style.display = 'block';
      const dashKyc = document.getElementById('dashKyc');
      const kycStatus = localStorage.getItem('pn_kyc_status') || 'Not Submitted';
      dashKyc.innerText = kycStatus.charAt(0).toUpperCase() + kycStatus.slice(1);
      dashboard.scrollIntoView({behavior:'smooth'});
    });
  }
});